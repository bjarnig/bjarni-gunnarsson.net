#!/bin/bash

cp "/Volumes/DATA/Courses/Classes/Programming and Music 2/25 - SC Buffers/SimpleLooper/SimpleLooper.scx" "/Volumes/DATA/bjarni/Library/Application Support/SuperCollider/extensions/SimpleUgens/"

cp "/Volumes/DATA/Courses/Classes/Programming and Music 2/25 - SC Buffers/SimpleLooper/SimpleLooper.sc" "/Volumes/DATA/bjarni/Library/Application Support/SuperCollider/extensions/SimpleUgens/"