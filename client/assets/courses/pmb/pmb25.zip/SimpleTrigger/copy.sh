#!/bin/bash

cp "/Volumes/DATA/Courses/Classes/Programming and Music 2/25 - SC Buffers/SimpleTrigger/SimpleTrigger.scx" "/Volumes/DATA/bjarni/Library/Application Support/SuperCollider/extensions/SimpleUgens/"

cp "/Volumes/DATA/Courses/Classes/Programming and Music 2/25 - SC Buffers/SimpleTrigger/SimpleTrigger.sc" "/Volumes/DATA/bjarni/Library/Application Support/SuperCollider/extensions/SimpleUgens/"